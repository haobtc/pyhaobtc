# -*- coding: utf-8 -*-

from .client import Client

VERSION = __version__ = '0.0.7'
